<header>
    <div class="container-fluid">
        <div class="row">
            @yield('header')
            <div class="col-md-6 text-end">
                <div class="header-noti">
                </div>
            </div>
        </div>
    </div>
</header>
