@extends('company.layouts.master')
@section('title')
    Dashboard
@endsection
<link href="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<style>
    .datepicker table tr td, .datepicker table tr th {
        padding: 10px; /* Adjust the padding value as needed */
    }

    .disabled {
        background-color: #f0ad4e !important;
        color: #ffffff;
    }

    .table-details {
        display: none;
    }

    .btn-show-details {
        cursor: pointer;
    }
</style>
@section('header')
    <div class="col-md-6">
        <div class="breadcrumb">
            <span>Dashboards</span>

        </div>
    </div>
@endsection
@section('content')

    <div class="container-fluid">
        {{--        <div class="row">--}}
        {{--            <div class="col-md-12">--}}
        {{--                <div class="filter-date">--}}
        {{--                    <select class="form-select">--}}
        {{--                        <option>Today</option>--}}
        {{--                        <option>Yesterday</option>--}}
        {{--                        <option>Last week</option>--}}
        {{--                        <option>Last Month</option>--}}
        {{--                        <option>Last Year</option>--}}
        {{--                    </select>--}}
        {{--                </div>--}}
        {{--            </div>--}}
        {{--        </div>--}}
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-3">
                <div class="dash-counter">
                    <span>Total Employees</span>
                    <h3>{{$employee_count}}</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dash-counter gray">
                    <span>Total Hours</span>
                    <h3>150</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dash-counter gray">
                    <span>Total Work Hours</span>
                    <h3>150</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dash-counter">
                    <span>Overtime Hours</span>
                    <h3>70</h3>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
            <div class="chart-heading">
                <h3>Company Employee</h3>
            </div>
            <div class="col-md-12">
                <table class="table table-borderless">
                    <thead class="dash-counter gray">
                    <tr class="text-white fs-5">
                        <th>Employee</th>
                        <th>Employee ID</th>
                        <th>Total work hours</th>
                        <th>Overtime</th>
                        <th>Total hours</th>
                        <th>Actions</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Karan</td>
                        <td>123456789</td>
                        <td>8 hours</td>
                        <td>2 hours</td>
                        <td>10 hours</td>
                        <td>
                            <button class="btn btn-success btn-sm btn-show-details">✓</button>
                            <button class="btn btn-danger btn-sm btn-hide-details">×</button>
                        </td>
                        <td>
                            <span class="toggle-icon cursor-pointer"><i class="fa-solid fa-arrow-down"></i></span>
                        </td>

                    </tr>
                    <tr class="table-details">
                        <td colspan="6">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Timesheet Management</td>
                                    <td>Create a employee dashboard page</td>
                                    <td>22/05/2024</td>
                                    <td>09:30 AM</td>
                                    <td>07:00 PM</td>
                                </tr>
                                <tr>
                                    <td>Timesheet Management</td>
                                    <td>Create a employee dashboard page</td>
                                    <td>22/05/2024</td>
                                    <td>09:30 AM</td>
                                    <td>07:00 PM</td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>Dharmik</td>
                        <td>123456788</td>
                        <td>6 hours</td>
                        <td>0 hours</td>
                        <td>6 hours</td>
                        <td>
                            <button class="btn btn-success btn-sm btn-show-details">✓</button>
                            <button class="btn btn-danger btn-sm btn-hide-details">×</button>
                        </td>
                        <td>
                            <span class="toggle-icon cursor-pointer"><i class="fa-solid fa-arrow-down"></i></span>
                        </td>
                    </tr>
                    <tr class="table-details">
                        <td colspan="6">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Timesheet Management</td>
                                    <td>Develop react App</td>
                                    <td>22/05/2024</td>
                                    <td>09:30 AM</td>
                                    <td>07:00 PM</td>
                                </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row mt-3">
            <div class="col-md-8">
                    <div class="chart-heading">
                        <h3>Holidays List</h3>
                    </div>
                    @if(empty($holidays))
                        <div class="alert alert-info" role="alert">
                            No holidays have been set yet.
                        </div>
                    @else
                        <table class="table table-striped nowrap" style="width:100%">
                            <thead>
                            <tr>
                                <th>Holiday Title</th>
                                <th>Holiday Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($holidays as $holiday)
                                <tr>
                                    <td>{{ $holiday->title }}</td>
                                    <td>{{ \Carbon\Carbon::parse($holiday->date)->format('F j, Y') }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    @endif
            </div>
            <div class="col-md-4">
                <div class="hotspot">
                    <h3 class="mb-2 mt-2">Holiday Calendar</h3>
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>

    </div>
@endsection
@section('custom-script')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function () {
            var holidays = @json($holidays);

            // Initialize Bootstrap Datepicker
            $('#calendar').datepicker({
                // daysOfWeekDisabled: [0, 6], // Disable weekends
                todayHighlight: true, // Highlight today's date
                datesDisabled: holidays.map(holiday => new Date(holiday.date)), // Mark holiday dates
                format: 'yyyy-mm-dd', // Set the date format
                beforeShowDay: function (date) {
                    var dateString = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
                    var holiday = holidays.find(h => h.date === dateString);
                    if (holiday) {
                        return {
                            classes: 'disabled',
                            tooltip: holiday.title
                        };
                    } else {
                        return {};
                    }
                }

            });
            $(document).on('mouseenter', '.disabled', function () {
                var date = $(this).data('date');
                var holiday = holidays.find(h => h.date === date);
                if (holiday) {
                    $(this).attr('title', holiday.title).tooltip('show');
                }
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.toggle-icon').click(function () {
                var $detailsRow = $(this).closest('tr').next('.table-details');
                $detailsRow.toggle();
                $(this).html($detailsRow.is(':visible') ? '<i class="fa-solid fa-arrow-up"></i>' : '<i class="fa-solid fa-arrow-down"></i>');
            });
        });
    </script>
@endsection
