<header>
    <div class="container-fluid">
        <div class="row">
            @yield('header')

            <div class="col-md-6 text-end">
{{--                <div class="header-noti">--}}
{{--                    <div class="header-search">--}}
{{--                        <div class="input-group">--}}
{{--                            <span class="input-group-text"><img src="{{asset('assets/admin/images/search.png')}}"></span>--}}
{{--                            <input type="text" class="form-control" placeholder="Search">--}}
{{--                            <span class="input-group-text"><img src="{{asset('assets/admin/images/icon.png')}}"></span>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="dropdown">--}}
{{--                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">--}}
{{--                            <img src="{{asset('assets/admin/images/bell.png')}}">--}}
{{--                        </button>--}}
{{--                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">--}}
{{--                            <li><a class="dropdown-item" href="#">Action</a></li>--}}
{{--                            <li><a class="dropdown-item" href="#">Another action</a></li>--}}
{{--                            <li><a class="dropdown-item" href="#">Something else here</a></li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
        </div>
    </div>
</header>
